def crear_producto_fake():
    return {
        "nombre": "Producto Fake",
        "clasificacion": "Categoria",
        "tipo_producto": "Tipo",
        "estado": "Activo",
        "impuestos": 0,
        "codigo_sku": "FAKE123",
        "marca": "Fake",
        "precio": 100,
        "cantidad": 5,
        "fecha_creacion": "2024-01-01T00:00:00",
        "sucursal_id": 1,
        "costo_neto_unitario": 50,
        "costo_neto_total": 250,
        "doc_recepcion_ing": "999"
    }
