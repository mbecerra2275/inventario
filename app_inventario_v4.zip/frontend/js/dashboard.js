// =========================================
// 📊 Dashboard - Cargar métricas generales
// Sistema de Inventario
// =========================================

// URL base del backend FastAPI
const API_URL = "http://127.0.0.1:8000";

// -----------------------------------------
// 🔹 Función principal para cargar métricas
// -----------------------------------------
async function cargarMetricas() {
  console.log("📊 Cargando métricas generales...");

  try {
    // 1️⃣ Llamada al backend para obtener todos los productos
    const response = await fetch(`${API_URL}/productos/`);

    // 2️⃣ Verificar respuesta válida
    if (!response.ok) throw new Error("Error al obtener productos");

    // 3️⃣ Convertir respuesta a JSON
    const productos = await response.json();

    // -----------------------------------------
    // 🧮 Calcular métricas generales
    // -----------------------------------------

    // Total de productos registrados
    const totalProductos = productos.length;

    // Suma total de stock (todas las unidades)
    const stockTotal = productos.reduce((acc, p) => acc + (p.cantidad || 0), 0);

    // 💰 Calcular total de ventas estimadas (precio × cantidad)
    const ventasTotales = productos.reduce((acc, p) => {
      const precio = p.precio || 0;
      const cantidad = p.cantidad || 0;
      return acc + (precio * cantidad);
    }, 0);

    // -----------------------------------------
    // 🧾 Mostrar resultados en el dashboard
    // -----------------------------------------
    document.getElementById("totalProductos").textContent = totalProductos;
    document.getElementById("stockTotal").textContent = stockTotal;
    document.getElementById("ventasMes").textContent = `$${ventasTotales.toLocaleString("es-CL")}`;

    console.log("✅ Métricas cargadas correctamente.");
  } catch (error) {
    console.error("❌ Error al cargar métricas:", error);
  }
}

// -----------------------------------------
// 🚀 Ejecutar automáticamente al cargar la página
// -----------------------------------------
document.addEventListener("DOMContentLoaded", cargarMetricas);
